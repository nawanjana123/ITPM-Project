import random
import re
import string
from string import punctuation
import _thread

import benepar
import nltk  # 3.4.1
import pymysql
import scipy
import spacy
import torch
from nltk import tokenize
from nltk.corpus import stopwords
from nltk.tokenize.treebank import TreebankWordDetokenizer as Twd
from rake_nltk import Rake  # 1.0.4
from sentence_transformers import SentenceTransformer
from serpapi import GoogleSearch
from summa.summarizer import summarize
from textblob import TextBlob
from transformers import T5ForConditionalGeneration, T5Tokenizer, GPT2Tokenizer, GPT2LMHeadModel
from reportlab.lib.colors import blue
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import inch
from reportlab.pdfgen.canvas import Canvas

from datetime import datetime

nltk.download("averaged_perceptron_tagger")
nltk.download("punkt")
nltk.download("stopwords")

model = T5ForConditionalGeneration.from_pretrained('ramsrigouthamg/t5_boolean_questions')
tokenizer = T5Tokenizer.from_pretrained('t5-base')
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
# print ("device ",device)
model_dev = model.to(device)

tokenizer_wrong = GPT2Tokenizer.from_pretrained("gpt2")
model_wrong = GPT2LMHeadModel.from_pretrained("gpt2",
                                              pad_token_id=tokenizer_wrong.eos_token_id)

nlp = spacy.load('en_core_web_sm')
benepar.download('benepar_en3')
benepar_parser_wrong = benepar.Parser('benepar_en3')
model_BERT = SentenceTransformer('bert-base-nli-mean-tokens')


class Document:
    def __init__(self, raw_string, sentences=None):
        """
        raw_string - string of a document
        Constructor for document, creates a document containing sentences
        """
        if sentences is None:
            self._raw_string = raw_string
            self.raw_sentences = nltk.sent_tokenize(raw_string)

        else:
            self._raw_string = " ".join(sentences)
            self.raw_sentences = sentences

    def get_gap_filled_questions(self):
        """
        Returns gap filled questions as a list of tuples
            List contains all questions.
            Tuple has for parts:
                Does this sentence has a question
                Sentence part before the gap
                Sentence part after the gap
                Word in gap
        """
        sentences = []
        for sen in self.raw_sentences:
            v = GapFilled()
            sentences.append(v.get_questions(sen))

        return sentences

    # [True, pre_sentence, post_sentence, blank]

    def get_wh_questions(self):

        q = []
        t = []
        for s in self.raw_sentences:
            tt = WH.gen_question(s)
            if (tt[0] not in t) and self._valid_wh(self, tt[0]):
                q.append(tt)
                t.append(tt[0])

        return q  # [[Q,A], [Q,A] ...]

    @staticmethod
    def _valid_wh(self, q):
        if q.strip().endswith("'?") or q.strip().endswith("’?"):
            return False

        words = q.split()
        if len(words) < 3:
            return False

        a = len(words)
        if words[a - 1] == words[a - 2]:
            return False

        return True

    def get_true_false_questions(self, question_count=10):
        q = []
        d = True
        # Max 10 questions
        i = 0
        for s in self.raw_sentences:
            n = TrueFalse()
            try:
                q.append(n.get_questions(s, tf=d))
                d = not d
                i += 1
            except Exception as exe:
                pass

            if i == 10:
                break
        random.shuffle(q)
        return q  # [[A,sent, ques]...]

    # def n_get_true_false_questions(self, question_count=10):
    #     q = []
    #     d = True
    #     # Max 10 questions
    #     count = 0
    #     for s in self.raw_sentences:
    #         n = TrueFalse()
    #         ls = list()
    #         n.n_get_questions(s, ls, count, tf=d)
    #         q.append(ls)
    #         d = not d
    #         count += 1
    #         if count == 10:
    #             break
    #     random.shuffle(q)
    #
    #     return q  # [[A,sent, ques]...]

    def get_mcq_questions(self):
        q = []

        for s in Wrongs.preprocess(self.raw_sentences):
            a = random.choice([1, 2])
            if a == 2:
                fff = Wrongs.get_candidate_sents(self._raw_string)
                fff = Wrongs.preprocess(fff)
                n = MCQ(fff, a)

            else:
                n = MCQ(s, a)

            q.append(n)
        return q  # [[A,sent, ques]...]

    def write_tf_statements(self, statements, tf):
        pass


class GapFilled:

    def get_questions(self, raw_string):
        """
        Gets all questions for sentence
        Returns dict of form {word: question}
        """
        words = nltk.word_tokenize(raw_string)

        # preprocess possible keywords and possible questions
        # for quicker runtime access
        keywords = self._preprocess_keywords(raw_string)
        r = self._preprocess_questions(words, keywords, raw_string)

        try:
            con = pymysql.connect(host="localhost", user="root", password="", database="question")
            q_db = con.cursor()

            t = raw_string.replace('"', "'")
            q_db.execute(f"INSERT INTO `sentences`(`sentence`, `meta`) VALUES ('{t}','0')")
            con.commit()
            q_db.close()
        except Exception as es:
            print(es)

        return r

    def _preprocess_questions(self, words, keywords, sentence):
        """
        Preprocesses clean words to create blanked questions
            using all clean words
        """

        self._questions = dict()

        # all possible words that can be used as answers
        clean_words = [word.lower() for word in words if self._is_clean(word, keywords)]
        dt = Twd()

        has_word = False
        breaking_index = 0
        words_copy = []

        for word in clean_words:
            # use lowercase for better equality check
            lower_words = [word.lower() for word in words]
            # don't use lower_words to preserve capitalization
            words_copy = words.copy()
            # put a blank in place of the word

            # Abstracted for loop
            for index in [index for index, value in enumerate(lower_words) if value == word]:
                has_word = True
                breaking_index = index
                break

            if has_word:
                break

        if has_word:
            blank = words_copy[breaking_index]

            pre_part = words_copy[0:breaking_index]
            if not breaking_index == len(words_copy) - 1:
                post_part = words_copy[breaking_index + 1:]
            else:
                post_part = []

            pre_sentence = dt.detokenize(pre_part)
            post_sentence = dt.detokenize(post_part)

            if pre_sentence == "" and post_sentence == "":
                return [False, pre_sentence, post_sentence, blank, sentence]
            return [True, pre_sentence, post_sentence, blank, sentence]

        else:
            return [False, "", "", "", sentence]

    @staticmethod
    def _is_clean(word, keywords):
        """
        word - full case word
        Applies rules to determine if word is good
        Returns true if word is usable, false otherwise
        """

        word_pos = nltk.pos_tag([word])[0][1]

        # check if its a keyword
        if not word.lower() in keywords:
            return False

        # normal ascii, no punctuation
        for char in word:
            if char not in string.printable:
                return False
            if char in string.punctuation:
                return False

        current = ["JJ", "JJR", "JJS", "NN", "NNS", "NNP", "NNPS"]
        # adj and noun only
        if word_pos not in current:
            return False

        # removes words like "use" (NN), but allows abbreviations
        if ((word_pos == "NN" or word_pos == "JJ") and len(word) <= 4) or (word_pos == "NNS" and len(word) <= 5):
            if word.islower() or word[:1].isupper() and word[1:].islower():
                return False

        # removes small unimportant words
        if word in stopwords.words("english"):
            return False

        return True

    @staticmethod
    def _preprocess_keywords(raw_string):
        """
        Preprocesses RAKE keywords to be used in
            question preprocessing
        Keywords will be all lowercase
        """

        r = Rake(max_length=1)
        r.extract_keywords_from_text(raw_string)
        return r.get_ranked_phrases()


class WH:
    @staticmethod
    def gen_question(line):
        """
        outputs question from the given text
        """
        answer = str(line)

        if type(line) is str:  # If the passed variable is of type string.
            line = TextBlob(line)  # Create object of type textblob.blob.TextBlob

        bucket = {}  # Create an empty dictionary

        for i, j in enumerate(line.tags):  # line.tags are the parts-of-speach in English
            if j[1] not in bucket:
                bucket[j[1]] = i  # Add all tags to the dictionary or bucket variable

        question = ''  # Create an empty string

        #  english part-of-speech tags used in this program.
        # .....................................................................
        # NNS     Noun, plural
        # JJ  Adjective
        # NNP     Proper noun, singular
        # VBG     Verb, gerund or present participle
        # VBN     Verb, past participle
        # VBZ     Verb, 3rd person singular present
        # VBD     Verb, past tense
        # IN      Preposition or subordinating conjunction
        # PRP     Personal pronoun
        # NN  Noun, singular or mass
        # .....................................................................

        # Create a list of tag-combination

        l1 = ['NNP', 'VBG', 'VBZ', 'IN']
        l2 = ['NNP', 'VBG', 'VBZ']

        l3 = ['PRP', 'VBG', 'VBZ', 'IN']
        l4 = ['PRP', 'VBG', 'VBZ']
        l5 = ['PRP', 'VBG', 'VBD']
        l6 = ['NNP', 'VBG', 'VBD']
        l7 = ['NN', 'VBG', 'VBZ']

        l8 = ['NNP', 'VBZ', 'JJ']
        l9 = ['NNP', 'VBZ', 'NN']

        l10 = ['NNP', 'VBZ']
        l11 = ['PRP', 'VBZ']
        l12 = ['NNP', 'NN', 'IN']
        l13 = ['NN', 'VBZ']

        if all(key in bucket for key in l1):  # 'NNP', 'VBG', 'VBZ', 'IN' in sentence.
            question = 'What' + ' ' + line.words[bucket['VBZ']] + ' ' + line.words[bucket['NNP']] + ' ' + line.words[
                bucket['VBG']] + '?'


        elif all(key in bucket for key in l2):  # 'NNP', 'VBG', 'VBZ' in sentence.
            question = 'What' + ' ' + line.words[bucket['VBZ']] + ' ' + line.words[bucket['NNP']] + ' ' + line.words[
                bucket['VBG']] + '?'


        elif all(key in bucket for key in l3):  # 'PRP', 'VBG', 'VBZ', 'IN' in sentence.
            question = 'What' + ' ' + line.words[bucket['VBZ']] + ' ' + line.words[bucket['PRP']] + ' ' + line.words[
                bucket['VBG']] + '?'


        elif all(key in bucket for key in l4):  # 'PRP', 'VBG', 'VBZ' in sentence.
            question = 'What ' + line.words[bucket['PRP']] + ' ' + ' does ' + line.words[bucket['VBG']] + ' ' + \
                       line.words[
                           bucket['VBG']] + '?'

        elif all(key in bucket for key in l7):  # 'NN', 'VBG', 'VBZ' in sentence.
            question = 'What' + ' ' + line.words[bucket['VBZ']] + ' ' + line.words[bucket['NN']] + ' ' + line.words[
                bucket['VBG']] + '?'

        elif all(key in bucket for key in l8):  # 'NNP', 'VBZ', 'JJ' in sentence.
            question = 'What' + ' ' + line.words[bucket['VBZ']] + ' ' + line.words[bucket['NNP']] + '?'

        elif all(key in bucket for key in l9):  # 'NNP', 'VBZ', 'NN' in sentence
            question = 'What' + ' ' + line.words[bucket['VBZ']] + ' ' + line.words[bucket['NNP']] + '?'

        elif all(key in bucket for key in l11):  # 'PRP', 'VBZ' in sentence.
            if line.words[bucket['PRP']] in ['she', 'he']:
                question = 'What' + ' does ' + line.words[bucket['PRP']].lower() + ' ' + line.words[
                    bucket['VBZ']].singularize() + '?'

        elif all(key in bucket for key in l10):  # 'NNP', 'VBZ' in sentence.
            question = 'What' + ' does ' + line.words[bucket['NNP']] + ' ' + line.words[
                bucket['VBZ']].singularize() + '?'

        elif all(key in bucket for key in l13):  # 'NN', 'VBZ' in sentence.
            question = 'What' + ' ' + line.words[bucket['VBZ']] + ' ' + line.words[bucket['NN']] + '?'

        # When the tags are generated 's is split to ' and s. To overcome this issue.
        if 'VBZ' in bucket and line.words[bucket['VBZ']] == "’":
            question = question.replace(" ’ ", "'s ")

        return [question, answer]


class TrueFalse:
    def get_questions(self, sentence, tf=True):

        if tf:
            try:
                con = pymysql.connect(host="localhost", user="root", password="", database="question")
                q_db = con.cursor()

                t = sentence.replace('"', "'")
                q_db.execute(f"INSERT INTO `sentences`(`sentence`, `meta`) VALUES ('{t}','0')")
                con.commit()
                q_db.close()
            except Exception as es:
                print(es)
            if len(sentence.split()) > 2:
                return [True, True, sentence, sentence]
            else:
                return [False, True, sentence, sentence]

        else:
            z = Wrongs()
            b = z.get_a_wrong_sentence(sentence)
            if b[0]:
                return [True, False, sentence, b[1]]
            return [False, False, '', '']

        # [Answer, sentence, question],

    # def n_get_questions(self, sentence, question, count, tf=True):
    #
    #     if tf:
    #         question = [True, True, sentence, sentence]
    #
    #     else:
    #         _thread.start_new_thread(self._w, (sentence, question, count))
    #     # [Answer, sentence, question],
    #
    # def _w(self, s, ls, count):
    #     z = Wrongs()
    #     b = z.get_a_wrong_sentence(s)
    #     if b[0]:
    #         ls = [True, False, s, b[1]]
    #         count += 1
    #     else:
    #         ls = [False, False, '', '']
    #         count += 1
    #


class MCQ:
    """
        MCQ types:
             1 -> Select the correct statement
             2 -> Select the incorrect statement
                    Need at least 5 sentences
             3 -> Select the correct / incorrect statement(s)
                    Need at least 3 sentences
    """
    _heads_type_1 = ["Select the correct answer.", "Which one of below is correct?", "Select the correct statement."]
    _heads_type_2 = ["Select the incorrect answer.",
                     "Which one of below is not correct?", "Select the incorrect statement."]

    def __init__(self, sentence, mcq_type):
        self.mcq_type = mcq_type
        self.question_head = ''
        self.question_body = ''
        self.answers = []
        self.correct_answer = 0
        self.success = False

        if type(sentence) == str:
            sentence = [sentence]

            try:
                con = pymysql.connect(host="localhost", user="root", password="", database="question")
                q_db = con.cursor()

                for se in sentence:
                    t = se.strip().replace('"', "'")
                    q_db.execute(f"INSERT INTO `sentences`(`sentence`, `meta`) VALUES ('{t}','0')")
                con.commit()
                q_db.close()
            except Exception as es:
                print(es)

        self.sentences = sentence

        zzz = Wrongs()
        try:
            if mcq_type == 1:
                self._create_correct_one_mcq(wrong_object=zzz)

            if mcq_type == 2:
                self._create_incorrect_one_mcq(wrong_object=zzz)
        except:
            self.success = False

    def _create_correct_one_mcq(self, wrong_object=None):
        self.question_head = random.choice(self._heads_type_1)
        self.mcq_type = 1
        self.question_body = ''

        self.answers = []
        self.correct_answer = 0
        self.success = False

        if wrong_object is None:
            wrong_object = Wrongs()

        incorrect = []

        if len(self.sentences) == 1:
            x = wrong_object.get_wrong_sentences_from_a_sentence(self.sentences[0])

            if x[0]:
                incorrect.extend(x[1])
            else:
                return

        elif len(self.sentences) > 4:
            random.shuffle(self.sentences)
            for i in range(0, 4):
                incorrect.append(wrong_object.get_a_wrong_sentence(self.sentences[i])[1])

        else:
            for i in range(0, 4):
                incorrect.append(wrong_object.get_a_wrong_sentence(random.choice(self.sentences))[1])

        random.shuffle(incorrect)
        self.correct_answer = random.randint(0, 4)

        for i in range(0, 5):
            if i == self.correct_answer:
                self.answers.append(random.choice(self.sentences))

            if i == 4:
                break
            self.answers.append(incorrect[i])
        self.success = True

    def _create_incorrect_one_mcq(self, wrong_object=None):
        self.question_head = random.choice(self._heads_type_2)
        self.mcq_type = 2
        self.question_body = ''

        self.answers = []
        self.correct_answer = 0
        self.success = False

        if wrong_object is None:
            wrong_object = Wrongs()

        if len(self.sentences) < 5:
            return

        random.shuffle(self.sentences)
        correct = self.sentences[:4]

        ss = wrong_object.get_a_wrong_sentence(self.sentences[4])
        if ss[0]:
            incorrect = ss[1]
        else:
            return

        random.shuffle(correct)
        self.correct_answer = random.randint(0, 4)

        for i in range(0, 5):
            if i == self.correct_answer:
                self.answers.append(incorrect)
            if i == 4:
                break
            self.answers.append(correct[i])
        self.success = True

    @staticmethod
    def get_questions(sentence):
        wa = Wrongs().get_wrong_sentences(sentence)[:4]
        random.shuffle(wa)
        i = random.randint(0, 3)
        wa.insert(i, sentence)

        return [sentence, i, wa]
        # [sentence, answer_index, [answers]]


class Wrongs:

    def __init__(self):
        self.tokenizer = tokenizer_wrong

        self.model = model_wrong
        self.benepar_parser = benepar_parser_wrong

        self.model_BERT = model_BERT

    @staticmethod
    def preprocess(sentences):
        output = []
        for sent in sentences:
            single_quotes_present = len(re.findall(r"['][\w\s.:;,!?\\-]+[']", sent)) > 0
            double_quotes_present = len(re.findall(r'["][\w\s.:;,!?\\-]+["]', sent)) > 0
            question_present = "?" in sent
            if single_quotes_present or double_quotes_present or question_present:
                continue
            else:
                output.append(sent.strip(punctuation))
        return output

    @staticmethod
    def get_candidate_sents(resolved_text, ratio=0.5):
        candidate_sents = summarize(resolved_text, ratio=ratio)
        candidate_sents_list = tokenize.sent_tokenize(candidate_sents)
        candidate_sents_list = \
            [re.split(r'[:;]+', x)[0] for x in candidate_sents_list]
        filtered_list_short_sentences = \
            [sent for sent in candidate_sents_list if 20 < len(sent) < 100]
        return filtered_list_short_sentences

    @staticmethod
    def get_flattened(t):
        sent_str_final = None
        if t is not None:
            sent_str = [" ".join(x.leaves()) for x in list(t)]
            sent_str_final = [" ".join(sent_str)]
            sent_str_final = sent_str_final[0]
        return sent_str_final

    @staticmethod
    def get_termination_portion(main_string, sub_string):
        combined_sub_string = sub_string.replace(" ", "")
        main_string_list = main_string.split()
        last_index = len(main_string_list)
        for k in range(last_index):
            check_string_list = main_string_list[k:]
            check_string = "".join(check_string_list)
            check_string = check_string.replace(" ", "")
            if check_string == combined_sub_string:
                return " ".join(main_string_list[:k])

        return None

    def get_right_most_vp_or_np(self, parse_tree, last_np=None, last_vp=None):
        if len(parse_tree.leaves()) == 1:
            return self.get_flattened(last_np), self.get_flattened(last_vp)
        last_subtree = parse_tree[-1]
        if last_subtree.label() == "NP":
            last_np = last_subtree
        elif last_subtree.label() == "VP":
            last_vp = last_subtree

        return self.get_right_most_vp_or_np(last_subtree, last_np, last_vp)

    def get_sentence_completions(self, filter_quotes_and_questions):
        sentence_completion_dict = {}
        for individual_sentence in filter_quotes_and_questions:
            sentence = individual_sentence.rstrip('?:!.,;')
            tree = self.benepar_parser.parse(sentence)
            last_noun_phrase, last_verb_phrase = self.get_right_most_vp_or_np(tree)
            phrases = []
            if last_verb_phrase is not None:
                verb_phrase_string = \
                    self.get_termination_portion(sentence, last_verb_phrase)
                phrases.append(verb_phrase_string)
            if last_noun_phrase is not None:
                noun_phrase_string = \
                    self.get_termination_portion(sentence, last_noun_phrase)
                phrases.append(noun_phrase_string)

            longest_phrase = sorted(phrases, key=len, reverse=True)
            if len(longest_phrase) == 2:
                first_sent_len = len(longest_phrase[0].split())
                second_sentence_len = len(longest_phrase[1].split())
                if (first_sent_len - second_sentence_len) > 4:
                    del longest_phrase[1]

            if len(longest_phrase) > 0:
                sentence_completion_dict[sentence] = longest_phrase
        return sentence_completion_dict

    def get_a_sentence_part(self, filter_quotes_and_question):

        individual_sentence = filter_quotes_and_question
        sentence = individual_sentence.rstrip('?:!.,;')
        tree = self.benepar_parser.parse(sentence)
        last_noun_phrase, last_verb_phrase = self.get_right_most_vp_or_np(tree)
        phrases = []
        if last_verb_phrase is not None:
            verb_phrase_string = \
                self.get_termination_portion(sentence, last_verb_phrase)
            phrases.append(verb_phrase_string)
        if last_noun_phrase is not None:
            noun_phrase_string = \
                self.get_termination_portion(sentence, last_noun_phrase)
            phrases.append(noun_phrase_string)

        longest_phrase = sorted(phrases, key=len, reverse=True)
        if len(longest_phrase) == 2:
            first_sent_len = len(longest_phrase[0].split())
            second_sentence_len = len(longest_phrase[1].split())
            if (first_sent_len - second_sentence_len) > 4:
                del longest_phrase[1]

        if len(longest_phrase) > 0:
            return [True, longest_phrase[0]]
        return [False, ""]

    def sort_by_similarity(self, original_sentence, generated_sentences_list):
        sentence_embeddings = self.model_BERT.encode(generated_sentences_list)

        queries = [original_sentence]
        query_embeddings = self.model_BERT.encode(queries)
        number_top_matches = len(generated_sentences_list)

        dissimilar_sentences = []

        for query, query_embedding in zip(queries, query_embeddings):
            distances = scipy.spatial.distance.cdist([query_embedding],
                                                     sentence_embeddings, "cosine")[0]

            results = zip(range(len(distances)), distances)
            results = sorted(results, key=lambda x: x[1])

            for idx, distance in reversed(results[0:number_top_matches]):
                score = 1 - distance
                if score < 0.9:
                    dissimilar_sentences.append(generated_sentences_list[idx].strip())

        sorted_dissimilar_sentences = sorted(dissimilar_sentences, key=len)

        return sorted_dissimilar_sentences[:10]

    def generate_sentences(self, partial_sentence, full_sentence, count=1):
        input_ids = torch.tensor([self.tokenizer.encode(partial_sentence)])
        maximum_length = len(partial_sentence.split()) + 80

        sample_outputs = self.model.generate(
            input_ids,
            do_sample=True,
            max_length=maximum_length,
            top_p=0.90,  # 0.85
            top_k=50,  # 0.30
            repetition_penalty=10.0,
            num_return_sequences=10
        )
        generated_sentences = []
        for n, sample_output in enumerate(sample_outputs):
            decoded_sentences = \
                self.tokenizer.decode(sample_output, skip_special_tokens=True)
            decoded_sentences_list = tokenize.sent_tokenize(decoded_sentences)
            generated_sentences.append(decoded_sentences_list[0])

        top_3_sentences = self.sort_by_similarity(full_sentence, generated_sentences)

        return top_3_sentences

    def generate_a_sentence(self, partial_sentence, full_sentence):
        input_ids = torch.tensor([self.tokenizer.encode(partial_sentence)])
        maximum_length = len(partial_sentence.split()) + 80

        sample_outputs = self.model.generate(
            input_ids,
            do_sample=True,
            max_length=maximum_length,
            top_p=0.90,  # 0.85
            top_k=50,  # 0.30
            repetition_penalty=10.0,
            num_return_sequences=1
        )
        generated_sentences = []
        for n, sample_output in enumerate(sample_outputs):
            decoded_sentences = \
                self.tokenizer.decode(sample_output, skip_special_tokens=True)
            decoded_sentences_list = tokenize.sent_tokenize(decoded_sentences)
            generated_sentences.append(decoded_sentences_list[0])
            if len(generated_sentences) > 0:
                break

        if len(generated_sentences) > 0:
            return [True, generated_sentences[0]]
        return [False, ""]

    def main(self, sentence):
        cand_sents = self.get_candidate_sents(sentence)
        filter_quotes_and_questions = self.preprocess(cand_sents)
        sent_completion_dict = \
            self.get_sentence_completions(filter_quotes_and_questions)

        torch.manual_seed(2020)

        tf_sentences = []
        for key_sentence in sent_completion_dict:
            partial_sentences = sent_completion_dict[key_sentence]
            false_sentences = []

            for partial_sent in partial_sentences:
                false_sents = self.generate_sentences(partial_sent, key_sentence)
                false_sentences.extend(false_sents)

            tf_sentence = [key_sentence, false_sentences]
            tf_sentences.append(tf_sentence)

        return tf_sentences

    def get_a_wrong_sentence(self, sentence):
        sentence_part = self.get_a_sentence_part(sentence)

        if sentence_part[0]:
            torch.manual_seed(2020)

            false_sentence = self.generate_a_sentence(sentence_part[1], sentence)

            if false_sentence[0]:
                return [True, false_sentence[1]]

        return [False, ""]

    def get_wrong_sentences(self, sentence, count=1):
        cand_sents = self.get_candidate_sents(sentence)
        filter_quotes_and_questions = self.preprocess(cand_sents)
        sent_completion_dict = \
            self.get_sentence_completions(filter_quotes_and_questions)

        torch.manual_seed(2020)

        for key_sentence in sent_completion_dict:
            partial_sentences = sent_completion_dict[key_sentence]
            false_sentences = []

            if len(partial_sentences) > 0:
                partial_sent = partial_sentences[0]
                false_sents = self.generate_sentences(partial_sent, key_sentence)
                false_sentences.extend(false_sents)

                return [key_sentence, false_sentences[:count]]

            else:
                return [key_sentence, ""]

    def get_wrong_sentences_from_a_sentence(self, sentence):
        sentence_part = self.get_a_sentence_part(sentence)

        if sentence_part[0]:
            torch.manual_seed(2020)

            false_sentences = []

            false_sents = self.generate_sentences(sentence_part[1], sentence, count=4)
            false_sentences.extend(false_sents)

            if false_sentences is not None and len(false_sentences) >= 4:
                return [True, false_sentences[:4]]

        return [False, []]


class Paper:
    TYPE_MCQ = 0
    TYPE_WH = 1
    TYPE_BLANK = 2
    TYPE_FINAL = 3

    types = ["MCQ paper", "WH question paper", "Gap filled paper", "Final paper"]

    errors = []

    def __init__(self, user_name, type_, title, duration,
                 paragraphs, count=(0, 0)):
        # Set up basics
        self.page_number = 1

        self.start_x = 35
        self.end_x = A4[0] - 35

        self.start_y = A4[1] - 60
        self.end_y = 60
        self.current_y = 0

        self.paper = self._draw_first_page(user_name, self.types[type_], title, duration)

        paragraphs = re.sub("\[\d+]", "", paragraphs)
        paragraphs = re.sub("\[\S+]", "", paragraphs)

        if type_ == Paper.TYPE_WH or type_ == Paper.TYPE_BLANK:

            paras = paragraphs.replace("\n\n\n", "\n\n")
            paras = paras.replace("\n\n\n", "\n\n")
            paras = paras.replace("\n\n\n", "\n\n")

            if count[0] == 1:
                paras = [paras]

            else:
                paras = paras.split("\n\n")
            if type_ == Paper.TYPE_WH:

                final_selection = self.pre_wh(paras, count=count)
                for i in range(len(final_selection)):
                    self.print_a_wh((i + 1), final_selection[i])

            else:
                r = self.pre_blank(paras, count=count)

                for d in r:
                    self.print_a_gap(d[0], d[1], d[2])
                    self.empty_line()

        elif type_ == Paper.TYPE_MCQ:
            e = Document(paragraphs)
            mcqs = e.get_mcq_questions()

            num = 1
            for mcq in mcqs:
                if mcq.success:
                    self.print_a_mcq(num, mcq)
                    self.empty_line()
                    num += 1
            if num == 1:
                self.errors.append("Couldn't create MCQ paper.")

        else:  # Final
            doc = Document(paragraphs)
            sent = doc.raw_sentences

            wh = []
            gap = []

            paras = paragraphs.replace("\n\n", "\n")
            paras = paras.replace("\n\n", "\n")
            paras = paras.split("\n")

            if len(sent) < 12:
                self.errors.append("Too few sentences!")

            else:
                if len(sent) < 50:
                    t = 12
                    y = t // 3
                    p = len(sent) // t

                else:
                    le = len(sent)
                    t = le // 4
                    y = t // 3
                    p = 4

                for i in range(p):
                    p1 = " ".join(sent[(i * t):(i * t) + y])
                    p2 = " ".join(sent[(i * t) + y:(i * t) + (2 * y)])
                    p3 = " ".join(sent[(i * t) + (2 * y):(i * t) + (3 * y)])

                    wh.append(self.pre_wh([p1], count=(1, 3)))
                    gap.append(self.pre_blank([p2]))
                    gap.append(self.pre_blank([p3]))

            self._generate_final_paper(wh, gap)

    def _generate_final_paper(self, wh: list, gap: list):
        if not 2 * len(wh) == len(gap):
            print("2Gap = WH")
            return

        for i in range(len(wh)):
            topic = f"Question {format(i + 1, '02d')}"

            if self.current_y < ((self.start_y - self.end_y) * 0.2):
                self._add_new_page()

            self._add_line(topic)
            self.empty_line()
            self.print_a_wh(1, wh[i][0])

            if self.current_y < ((self.start_y - self.end_y) * 0.2):
                self._add_new_page()
            else:
                self.empty_line()

            index = ((i + 1) * 2) - 2
            self.print_a_gap(2, gap[index][0][1], gap[index][0][2])

            if self.current_y < ((self.start_y - self.end_y) * 0.2):
                self._add_new_page()
            else:
                self.empty_line()

            self.print_a_gap(3, gap[index + 1][0][1], gap[index + 1][0][2])
            self.empty_line()

    def _draw_first_page(self, user_name, type_, title, duration):
        #   Drawing first page
        now = datetime.now()
        date_time = now.strftime("%m-%d-%Y, %H-%M-%S")
        name = f"{user_name} - {type_}"
        fn = f'files/{name}.pdf'
        self.full_name = name + ".pdf"
        canvas = Canvas(fn, pagesize=A4)
        canvas.setTitle(title)

        canvas.drawImage("images/firstpage.png", 0, 0,
                         preserveAspectRatio=True, width=A4[0],
                         height=A4[1])

        canvas.setFont("Helvetica", 16)

        temp = ''
        if len(duration) == 2:
            temp = f'{duration[0]} hours {duration[1]} mins.'
        if len(duration) == 1:
            temp = f'{duration[0]} mins.'

        duration = temp

        canvas.drawString(35, A4[1] - 135, type_)
        y = canvas.stringWidth(duration, fontName="Helvetica", fontSize=16)
        canvas.drawString(A4[0] - 35 - y,
                          A4[1] - 135,
                          duration)

        n = f'- {format(self.page_number, "02d")} -'
        x = (A4[0] - canvas.stringWidth(n, fontName="Helvetica", fontSize=14)) / 2

        canvas.setFont("Helvetica", 14)
        canvas.setFillColorRGB(0.314, 0.314, 0.314)

        canvas.drawString(x, 30, n)

        canvas.setFont("Helvetica", 16)
        canvas.setFillColorRGB(0, 0, 0)

        self.current_y = A4[1] - (160 + 16)

        return canvas

    def get_file_name(self):
        return self.full_name

    def pre_wh(self, paragraphs, count=(4, 3)):

        selection_e = []  # [Paragrapph, [Questions]]
        selection_i = []  # [Paragrapph, [Questions]]

        wh = []
        for para in paragraphs:
            doc = Document(para)

            wh.append(doc.get_wh_questions())

        p_ind = 0
        for paragraph in wh:

            questions = []
            random.shuffle(paragraph)

            for question in paragraph:
                if question[0] != '' and len(question[0]) > 10:
                    questions.append(question[0])

            if count[1] != 0:
                questions = questions[:count[1]]

            if len(questions) > 0:
                if count[1] <= len(questions):
                    selection_e.append([paragraphs[p_ind], questions])

                else:
                    selection_i.append([paragraphs[p_ind], questions])

            p_ind += 1

        random.shuffle(selection_e)
        random.shuffle(selection_i)

        if count[0] == 0:
            final_selection = selection_e + selection_i

        elif count[0] <= len(selection_e):
            final_selection = selection_e[:count[0]]

        else:
            tem = selection_e + selection_i
            final_selection = tem[:count[0]]

        return final_selection

    def pre_blank(self, paras, count=(0, 0)):
        r = []
        gaps = []
        length = []

        for para in paras:
            doc = Document(para)
            t = doc.get_gap_filled_questions()
            for cc in t:
                if cc[0]:
                    break
            else:
                continue
            length.append(len(t))
            gaps.append(t)
            # return [True, pre_sentence, post_sentence, blank, sentence]

        if count[0] <= len(gaps) and count[0] != 0:
            random.shuffle(gaps)
            gaps = gaps[:count[0]]

        for i in range(len(gaps)):
            # return [True, pre_sentence, post_sentence, blank, sentence]
            answers = []
            index = 0
            true_id = []
            j = 0
            for g in gaps[i]:
                if g[0]:
                    true_id.append(j)
                j += 1

            if len(true_id) > count[1] and count[1] != 0:
                random.shuffle(true_id)
                true_id = true_id[:count[1]]

            sentences = []

            ans = 1
            for j in range(len(gaps[i])):
                g = gaps[i][j]
                if j in true_id:
                    answers.append(g[3])
                    if g[1] != '':
                        s = f"{g[1]} ({ans}) ____ {g[2]}"
                    else:
                        s = f"({ans}) ____ {g[2]}"
                    ans += 1
                    sentences.append(s)
                else:
                    sentences.append(g[4])

            random.shuffle(answers)
            r.append([i + 1, sentences, answers])
        return r

    def print_a_mcq(self, number, mcq: MCQ,
                    fontName="Helvetica", fontSize=16):

        head_p = f'({format(number, "02d")}) '
        head = self._wrap_text(mcq.question_head, prefix=head_p)

        body = []
        body_p = ''
        if len(mcq.question_body) > 0:
            b = self._wrap_text(mcq.question_head)
            body.append(b)

        answers = []
        answers_p = []
        ans_h = 0
        for i in range(len(mcq.answers)):
            ans_p = f'{i + 1}. '
            answers_p.append(ans_p)
            in_a = self._wrap_text(mcq.answers[i], prefix=head_p + body_p + ans_p)
            ans_h += len(in_a)
            answers.append(in_a)

        height = (len(head) + len(body) + ans_h + 1) * fontSize

        if self.current_y - height < self.end_y:
            self._add_new_page()

        self._add_lines(head, all_prefix='', prefix=head_p)

        if len(body) > 0:
            self._add_lines(body, all_prefix=head_p, prefix=body_p)

        self.empty_line()

        for i in range(len(answers)):
            self._add_lines(answers[i], all_prefix=head_p + body_p, prefix=answers_p[i])

    def print_a_wh(self, number, wh, prefix=''):
        """
        number - Question number
        wh
        wh[0] - Paragraph
        wh[1] - List of questions
        """

        p = f'({number}) '

        self._add_line("Read the paragraph and answer the questions.",
                       showable_prefix=p, all_prepix=prefix)
        self.empty_line()

        self._add_lines(self._wrap_text(wh[0], prefix=(p + prefix)),
                        all_prefix=(p + prefix))
        self.empty_line()

        for i in range(len(wh[1])):
            self._add_lines(self._wrap_text(wh[1][i], prefix=(p + f'{i + 1}). ')),
                            all_prefix=(p + prefix), prefix=f'{i + 1}). ')

    def print_a_gap(self, number, sentences, answers, prefix=''):
        head_p = f'({number}) '
        self._add_line("Fill blanks by choosing correct words.",
                       showable_prefix=head_p, all_prepix=(prefix))
        self.empty_line()

        fs = " ".join(sentences)
        fa = ", ".join(answers)
        fa = fa.lower()

        self._add_lines(self._wrap_text(fs, prefix=(head_p + prefix)),
                        all_prefix=(head_p + prefix))
        self.empty_line()

        self._add_lines(self._wrap_text(f'[{fa}]', prefix=(head_p + prefix)),
                        all_prefix=(head_p + prefix))

    def _fill_lines_with_space(self, lines, pre_fix):

        r = []

        r.append(pre_fix + lines[0])

        for i in lines[1:]:
            r.append(" " * (len(pre_fix) + 1) + i)

        return r

    def _add_new_page(self):
        self.page_number += 1

        self.paper.showPage()
        self.paper.line(self.start_x, A4[1] - 50, self.end_x, A4[1] - 50)
        self.paper.line(self.start_x, 50, self.end_x, 50)

        n = f'- {format(self.page_number, "02d")} -'
        x = (A4[0] - self.paper.stringWidth(n, fontName="Helvetica", fontSize=14)) / 2

        self.paper.setFont("Helvetica", 14)
        self.paper.setFillColorRGB(0.314, 0.314, 0.314)

        self.paper.drawString(x, 30, n)

        self.paper.setFont("Helvetica", 16)
        self.paper.setFillColorRGB(0, 0, 0)

        self.current_y = A4[1] - (60 + 16)

    def close(self):
        self.paper.save()

    def add_text(self, text, fontName="Helvetica", fontSize=16):
        self.paper.setFont(fontName, fontSize)

        p = self._wrap_text(text, fontName=fontName, fontSize=fontSize, prefix="01) ")

        self._add_lines(p, prefix="01) ")

    def _add_line(self, text, fontName="Helvetica", fontSize=16, all_prepix='', showable_prefix=''):
        self.paper.setFont(fontName, fontSize)

        if self.current_y - fontSize < self.end_y:
            self._add_new_page()

        s = self.start_x
        if all_prepix != '':
            s += self.paper.stringWidth(all_prepix, fontName="Helvetica", fontSize=16)

        if showable_prefix != '':
            text = showable_prefix + text

        self.paper.drawString(s, self.current_y, text)
        self.current_y -= (fontSize * 1.25)

    def _add_lines(self, lines, fontName="Helvetica", fontSize=16, all_prefix='', prefix=''):

        self._add_line(lines[0], all_prepix=all_prefix, showable_prefix=prefix)
        for line in lines[1:]:
            self._add_line(line, all_prepix=(all_prefix + prefix))

    def empty_line(self, fontName="Helvetica", fontSize=16):
        self.paper.setFont(fontName, fontSize)

        if self.current_y - fontSize < self.end_y:
            self._add_new_page()

        self.current_y -= (fontSize * 1.25)

    def _wrap_text(self, text: str, fontName="Helvetica", fontSize=16, prefix=''):
        # Returns [] of lines
        t = text.splitlines()

        wrapped = []

        for line in t:
            tw = self.paper.stringWidth((prefix + line), fontName=fontName, fontSize=fontSize)

            if tw + self.start_x <= self.end_x:
                wrapped.append(line)

            else:
                b = line.split()
                te = ''

                for i in range(len(b)):

                    word = b[i]
                    if te != '':
                        z = te + " " + word
                    else:
                        z = te + word

                    c = self.paper.stringWidth((prefix + z), fontName=fontName, fontSize=fontSize)

                    if (c + self.start_x <= self.end_x):
                        te = z

                        if i == len(b) - 1:
                            wrapped.append(te)
                            continue

                        if c + self.start_x == self.end_x:
                            wrapped.append(te)
                            te = ''

                    else:
                        wrapped.append(te)
                        te = word

                        if i == len(b) - 1:
                            wrapped.append(word)

        return wrapped


class Answer:
    @staticmethod
    def get_gap_filled_answer(paragraph: str):
        paragraph = paragraph.strip()

        if "Fill blanks by choosing correct words." in paragraph:
            f = paragraph.split("Fill blanks by choosing correct words.")
            paragraph = f[1].strip()

        if "[" not in paragraph:
            return False

        if paragraph.count("[") != 1:
            return False

        a = paragraph.split("[")

        p = (a[0].strip()).replace("'", "\\'")
        p = p.replace('"', '\\"')
        w = (a[1].replace("]", '')).split(", ")

        q = Document(p)
        e = q.raw_sentences

        num = 1

        con = pymysql.connect(host="localhost", user="root", password="", database="question")
        q_db = con.cursor()

        d = list()
        for sen in e:
            if " _____" in sen:
                for word in w:
                    sentence = sen.replace(f"({num}) _____", word.strip())
                    v = q_db.execute \
                        (f'SELECT * FROM `sentences` WHERE sentence="{sentence}";')

                    if v > 0:
                        r = q_db.fetchone()
                        d.append(word)
                        num += 1
                        w.remove(word)
                        break

        con.close()
        if len(d) < 1:
            return False

        else:
            return d

    @staticmethod
    def is_true(sentence):
        con = pymysql.connect(host="localhost", user="root", password="", database="question")
        q_db = con.cursor()

        r = q_db.execute \
            (f'SELECT * FROM `sentences` WHERE sentence="{sentence}";')

        return r >= 1

    @staticmethod
    def get_mcq_answer(q):
        pass

    @staticmethod
    def get_wh_answer(question):
        params = {
            "q": question,
            "location": "Austin, Texas, United States",
            "hl": "en",
            "gl": "us",
            "google_domain": "google.com",
            "api_key": "1e093744e48294f00fc5dfa52b56d05e9c61a851da7cd6d216d9cc2885ab364f"
        }

        try:
            search = GoogleSearch(params)
            results = search.get_dict()
            ans_box = results.get("answer_box")

            return ans_box.get("answer")
        except:
            return False
