import os
import random
import re

import pymysql
from flask import Flask, render_template, request, session, render_template_string, send_from_directory

import eduall

app = Flask(__name__)
from tika import parser

import os
from flask import Flask, flash, request, redirect, url_for
from werkzeug.utils import secure_filename

UPLOAD_FOLDER = 'temp_uploads'
ALLOWED_EXTENSIONS = {'pdf'}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER


def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def get_error(message, content="", file_path="templates/signin.html",
              placeholder="<!--   PLACE_HOLDER_ERROR_MESSAGE     -->"):
    if content == "":
        a = open(file_path, 'r').read()
    else:
        a = content
    t = '{ x.className = x.className.replace("show", ""); }'
    r = f'''        <div id="snackbar">{message}</div>
    <script>
        var x = document.getElementById("snackbar");
        x.className = "show";
        setTimeout(function(){t}, 3000);

    </script>'''
    return a.replace(placeholder, r)


@app.errorhandler(500)
def page_not_found(e):
    return render_template("error.html")


@app.errorhandler(400)
def page_not_found(e):
    return render_template("error.html")


@app.errorhandler(404)
def page_not_found(e):
    return render_template("error.html")


@app.route('/')
def home(error_message=False):
    if not session.get('logged_in'):
        if not error_message:
            return render_template('signin.html')

        a = get_error(error_message, file_path="templates/signin.html",
                      placeholder="<!--   PLACE_HOLDER_ERROR_MESSAGE     -->", )
        return render_template_string(a)
    else:

        return render_template_string(first_home())


@app.route("/sign-up", methods=['POST'])
def sign_up():
    return render_template("signup.html")


@app.route("/sign-in", methods=['POST'])
def sign_in():
    return render_template("signin.html")


@app.route('/register', methods=['POST'])
def register():
    details = request.form
    first = details['First Name']
    title = details['title']
    last = details['Last Name']
    contact = details['Contact No']
    email = details['email']
    faculty = details['Faculty']
    qualifications = details['Qualifications']
    password = details['psw']
    Type = details["type"]

    try:
        con = pymysql.connect(host="localhost", user="root", password="", database="Users")
        cur = con.cursor()
        cur.execute("select * from member where email=%s", email)
        row = cur.fetchone()
        # print(row)
        if row != None:

            return render_template_string \
                (get_error("Email already in use!",
                           file_path="templates/signup.html",
                           placeholder="<!--   PLACE_HOLDER_ERROR_MESSAGE     -->"))

        else:
            cur.execute(f"INSERT INTO `member`(`title`, `fname`, `lname`, `contact`, `email`,"
                        f" `faculty`, `qualification`, `password`, `type`) VALUES ('"
                        f"{title}','{first}','{last}','{contact}','{email}',"
                        f"'{faculty}','{qualifications}','{password}','{Type}')")

        con.commit()
        con.close()

        return home()

    except Exception as es:
        return render_template_string \
            (get_error("Unknown error occurred!", file_path="templates/signup.html",
                       placeholder="<!--   PLACE_HOLDER_ERROR_MESSAGE     -->"))


@app.route('/index', methods=['POST'])
def do_login():
    login = request.form

    userName = login['username']
    password = login['password']

    try:
        con = pymysql.connect(host="localhost", user="root", password="", database="users")
        cur = con.cursor()
        cur.execute("select * from member where email=%s",
                    userName)
        row = cur.fetchone()
        cur.close()

        if row == None:
            return home(error_message="User does not exist.")

        cur2 = con.cursor()
        cur2.execute(f"select * from member where email='{userName}' and password='{password}'")

        row2 = cur2.fetchone()

        if row2 is None:
            return home(error_message="Password is not correct.")

        session['title'] = row2[0]
        session['user name'] = row2[1]

        session['logged_in'] = True
        session['email'] = userName

        if row2[8] == "Student":
            session['student'] = True
        else:
            session['student'] = False

        con.commit()
        con.close()

        return home()

    except Exception as es:
        print(es)
        return home(error_message="Unknown error! Please try again later.")


@app.route('/logout', methods=['POST'])
def logout():
    session['logged_in'] = False
    return home()


def get_txt(file_name):
    path = "temp_uploads\\" + file_name

    raw = parser.from_file(path)
    os.remove(path)

    return raw["content"].replace("\n", "")


@app.route("/question-generation", methods=['POST'])
def generate_a_question():
    return render_template_string(basic_question(first=True))


@app.route("/answer-generation", methods=['POST'])
def generate_an_answer():
    return render_template_string(basic_answer(first=True))


@app.route("/paper-generation", methods=['POST'])
def generate_a_paper():
    return render_template_string(basic_paper(first=True))


@app.route('/result', methods=['POST'])
def result():
    """
        Tearcher        ||  Student
    1 ==> WH
    2 ==> Blank
    3 ==> MCQ
    4 ==> Final         || T/F
    5 ==> Ans WH
    6 ==> Ans Blank
    7 ==> Ans Axillary
    8 ==> Ans Yes No

    """
    submission = request.form
    # Check has file
    if 'file' in request.files:
        file = request.files['file']
        if file.filename != '' and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            pre = str(random.randint(1000, 99999)) + "_"
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], pre + filename))
            text = get_txt(pre + filename)
            keys = submission.keys()

            a = dict()
            for key in keys:
                a[key] = submission[key]

            a['text'] = text
            submission = a

    return handle_result(submission)


def handle_result(submission, bot=False):
    success = False
    text = submission['text']

    question = ''
    answer = ''

    is_question = True
    gen = eduall.Document(text)
    custom_error = ""

    if submission['question'] == "5":
        is_question = False
        answer = eduall.Answer.get_wh_answer(text.strip())
        if answer:
            success = True

    if submission['question'] == "7":
        is_question = False

        mt = text.strip()
        ty = -1  # Undef
        q_part = ''

        for word in eduall.MCQ._heads_type_1:
            if word in mt:
                ty = 1  # One correct
                q_part = mt.split(word)[1]
                break
        else:
            for word in eduall.MCQ._heads_type_2:
                if word in mt:
                    ty = 0  # One incorrect
                    q_part = mt.split(word)[1]
                    break

        if ty != -1:
            q_part = q_part.strip()
            ans = q_part.split("\n")
            if len(ans) == 5:
                answers = []
                for number in range(1, 6):
                    answers.append((ans[number - 1].replace(f"{number}. ", "")).strip())

                answer_index = -1
                count = 0
                for ind in range(5):
                    if eduall.Answer.is_true(answers[ind].strip()):
                        if ty == 1:
                            answer_index = ind
                            count += 1
                    else:
                        if ty == 0:
                            answer_index = ind
                            count += 1

                if count == 1 and answer_index != -1:
                    answer = f"{answer_index + 1} ({answers[answer_index]})"
                    success = True

    if submission['question'] == "6":
        is_question = False
        r = eduall.Answer.get_gap_filled_answer(text)

        ans = ''
        n = 1

        if r:
            for an in r:
                ans += f"{n}) {an}<br>"
                n += 1
            success = True
            answer = ans

    if submission['question'] == "8":
        is_question = False
        b_t = text.strip().split("\n")

        answ = []
        answ_p = []
        for sen in b_t:
            sen = sen.strip()
            if sen != "Identify whether below questions are true or false." and sen != "":
                sent = ''
                sen_t = sen.split(")")
                if len(sen_t) > 2:
                    sent = ")".join(sen_t[1:])
                    answ_p.append(sen_t[0])
                elif len(sen_t) == 2:
                    sent = sen_t[1]
                    answ_p.append(sen_t[0])
                else:
                    sent = sen

                sent = sent.strip()
                answ.append(str(eduall.Answer.is_true(sent)))

        if len(answ) > 0:
            success = True
            answer = ''
            if len(answ) == len(answ_p):
                for i in range(len(answ)):
                    answer += f"{answ_p[i]} {answ[i]}<br>"

            else:
                for i in range(len(answ)):
                    answer += f"{b_t[i]} - {answ[i]}<br>"

    if session['student'] or bot:
        if submission['question'] == "1":
            r = gen.get_wh_questions()
            q = []
            a = []

            index = 1
            for qa in r:
                qq = qa[0]

                if len(qq) > 0:
                    q.append(f"{format(index, '02d')}.) {qq}")
                    a.append(f"{format(index, '02d')}.) {qa[1]}")
                    index += 1

            question = "Answer following WH questions.<br><br>" + "<br>".join(q)
            answer = "<br>".join(a)

            is_question = True
            success = index != 1

        if submission['question'] == "2":
            r = gen.get_gap_filled_questions()

            q = []
            a = []
            an = []
            index = 1
            for qa in r:
                if qa[0]:
                    q.append(f"{qa[1].strip()} ({index}) _____ {qa[2].strip()}")
                    a.append(f"{index}). {qa[3]}")
                    an.append(qa[3])
                    index += 1

                else:
                    q.append(qa[4])

            success = index != 1

            random.shuffle(an)
            question = "Fill blanks by choosing correct words.<br><br>" \
                       + " ".join(q) + "<br><br>[" + (", ".join(an)) + "]"

            answer = "<br>".join(a)

            is_question = True

        if submission['question'] == "3":
            r = gen.get_mcq_questions()

            q = []
            a = []
            index = 1

            for qa in r:
                if qa.success:
                    ques = f"{format(index, '02d')}). {qa.question_head}<br><br>"
                    for k in range(len(qa.answers)):
                        answe = f"<br>&emsp;{k + 1}. {qa.answers[k]}"
                        if not answe.endswith("."):
                            answe += "."
                        ques += answe
                    q.append(ques)

                    a.append(f"{index}. ({str(qa.correct_answer + 1)})")
                    index += 1

            success = index != 1
            question = "Answer all questions.<br><br>" \
                       + "<br><br>".join(q)

            answer = "<br>".join(a)

            is_question = True

        if submission['question'] == "4":
            #                return [True, False, sentence, b[1]]
            r = gen.get_true_false_questions()
            q = []
            a = []

            index = 1
            for qa in r:

                if qa[0]:
                    q.append(f"{format(index, '02d')}.) {qa[3]}")
                    a.append(f"{format(index, '02d')}.) {str(qa[1])}")
                    index += 1

            question = "Identify whether below questions are true or false.<br><br>" + "<br>".join(q)
            answer = "<br>".join(a)

            is_question = True
            success = index != 1

    else:
        is_question = True
        if submission['question'] == "1":
            type_ = eduall.Paper.TYPE_WH
        if submission['question'] == "2":
            type_ = eduall.Paper.TYPE_BLANK

        if submission['question'] == "3":
            type_ = eduall.Paper.TYPE_MCQ

        if submission['question'] == "4":
            type_ = eduall.Paper.TYPE_FINAL
            co = (4, 3)

        else:

            try:
                one = int(submission['co_q'])
            except:
                one = 0

            try:
                two = int(submission['co_sq'])
            except:
                two = 0

            co = (one, two)

        du = tuple(map(int, (submission['du_hour'], submission['du_min'])))

        title = submission['title']

        paper = eduall.Paper(session['user name'], type_, title,
                             du, submission['text'], count=co)

        if len(paper.errors) == 0:
            paper.close()
            p = paper.get_file_name()
            return send_from_directory("files", p)
        else:
            custom_error = paper.errors[0]

    if bot:
        if success:
            if question:
                return question
            return answer

        else:
            return False

    return render_template_string \
        (gen_result(success, is_question,
                    text, question, answer, submission['question'],
                    custom_error=custom_error))


@app.route('/from-bot')
def from_bot():
    """
        Tearcher        ||  Student
    1 ==> WH
    2 ==> Blank
    3 ==> MCQ
    4 ==> Final         || T/F
    5 ==> Ans WH
    6 ==> Ans Blank
    7 ==> Ans Axillary
    8 ==> Ans Yes No

    """

    d = request.args
    try:
        sub = dict()
        sub["text"] = d["txt"]
        q = str(int(d["type"]) - 2)

        sub["question"] = q
        #        return str(bot.get_response(userText))
        response = handle_result(sub, bot=True)

        if response:
            return response
        else:
            return "Couldn't process your request."


    except:
        return "Couldn't process your request."


def gen_result(succes, is_qusetion, text, question, answer, radio, custom_error=""):
    Map = {"1": "Q_wh", "5": "Q_wh", "2": "Q_BLANK", "6": "Q_BLANK", "3": "Q_MCQ", "7": "Q_MCQ", "4": "Q_FINAL",
           "8": "Q_FINAL", }

    if not is_qusetion:
        page = basic_answer()

    else:
        if session['student']:
            page = basic_question()

        else:
            page = basic_paper()

    if succes:

        page_q = open("templates/result.html", 'r').read()
        if is_qusetion:
            page_q = page_q.replace("PLACE_HOLDER_QUESTION_TITLE", "Question(s)")
            page_q = page_q.replace("PLACE_HOLDER_QUESTIONS", question)

            page_a = open("templates/result_hidden.html", 'r').read()
            page_a = page_a.replace("PLACE_HOLDER_RESUL_HIDDEN_TITLE",
                                    "Answer(s)")
            page_a = page_a.replace("<h4>PLACE_HOLDER_RESUL_HIDDEN</h4>",
                                    f"<h4>{answer}</h4>")

            page_q = page_q.replace("<<<PLACE_HOLDER_HIDDEN_RESULTS>>>",
                                    page_a)

        else:
            page_q = page_q.replace("PLACE_HOLDER_QUESTION_TITLE", "Answer(s)")
            page_q = page_q.replace("PLACE_HOLDER_QUESTIONS", answer)
            page_q = page_q.replace("<<<PLACE_HOLDER_HIDDEN_RESULTS>>>",
                                    "")

        page = page.replace(f'name="question" value="{radio}"  required >',
                            f'name="question" checked="true" value="{radio}"  required >')

        page = page.replace("//<!--PLACE_HOLDER_SELECTED-->",
                            f'document.getElementById("{Map[radio]}").checked="true"')

        page = page.replace("<!-- PLACE_HOLDER_RESULT -->",
                            page_q)
    else:
        if custom_error != "":
            error = custom_error
            pass

        elif is_qusetion:
            error = "Failed to create question(s)"
        else:
            error = "Failed to create answer(s)"

        page = get_error(error, content=page)

    page = page.replace(
        '<textarea id="type_que_or_ans" name="text" rows="10" cols="500" class="form-control" required></textarea>',
        f'<textarea id="type_que_or_ans" name="text" rows="10" cols="500" class="form-control" required>{text}</textarea>')

    return page


def first_home():
    page = open("templates/selection.html", 'r').read()
    page = page.replace("<h1>Welcome to username_PLACE_HOLDER!</h1>",
                        f"<h1>Welcome {session['title']} {session['user name']}!</h1>")

    if session['student']:
        page = page.replace("SELECTION_PLACE_HOLDER", "Generate a question")

    else:
        page = page.replace("SELECTION_PLACE_HOLDER", "Generate a paper")
    return page


def basic_answer(first=False):
    page = open("templates/answer-generation.html", 'r').read()
    page = page.replace("<h1>Welcome to username_PLACE_HOLDER!</h1>",
                        f"<h1>Welcome {session['title']} {session['user name']}!</h1>")

    page = page.replace("Ratio05_PLACE_HOLDER", "WH")
    page = page.replace("Ratio06_PLACE_HOLDER", "Blank")
    page = page.replace("Ratio07_PLACE_HOLDER", "MCQ")
    page = page.replace("Ratio08_PLACE_HOLDER", "True/False")
    if first:
        page = page.replace("<!--PLACE_HOLDER_SELECTED-->",
                            'document.getElementById("Q_WH").checked=true')
    return page


def basic_question(first=False):
    page = open("templates/question-generation.html", 'r').read()
    page = page.replace("<h1>Welcome to username_PLACE_HOLDER!</h1>",
                        f"<h1>Welcome {session['title']} {session['user name']}!</h1>")

    page = page.replace("Ratio01_PLACE_HOLDER", "WH")
    page = page.replace("Ratio02_PLACE_HOLDER", "Blank")
    page = page.replace("Ratio03_PLACE_HOLDER", "MCQ")
    page = page.replace("Ratio04_PLACE_HOLDER", "True/False")

    if first:
        page = page.replace("<!--PLACE_HOLDER_SELECTED-->",
                            'document.getElementById("Q_WH").checked=true')
    return page


def basic_paper(first=False):
    page = open("templates/paper-generation.html", 'r').read()
    page = page.replace("<h1>Welcome to username_PLACE_HOLDER!</h1>",
                        f"<h1>Welcome {session['title']} {session['user name']}!</h1>")

    page = page.replace("Ratio01_PLACE_HOLDER", "WH")
    page = page.replace("Ratio02_PLACE_HOLDER", "Blank")
    page = page.replace("Ratio03_PLACE_HOLDER", "MCQ")
    page = page.replace("Ratio04_PLACE_HOLDER", "Final")

    page = page.replace("Generate a question</button>", "Generate a paper</button>")

    if first:
        page = page.replace("<!--PLACE_HOLDER_SELECTED-->",
                            'document.getElementById("Q_WH").checked=true')
    return page


if __name__ == "__main__":
    app.secret_key = os.urandom(12)
    app.run(debug=False, host='0.0.0.0', port=5000)
