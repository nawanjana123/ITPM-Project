/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cazzendra.pos.core;

public final class CommonConstants {
    
    public class sql {

        public static final String AND = " AND ";
        public static final String OR = " OR ";
        public static final String EQUAL = " = ";
        public static final String NOT_EQUAL = " != ";
        public static final String LIKE = " LIKE ";
        public static final String WHERE = " WHERE ";
        public static final String SELECT = " SELECT ";
        public static final String INSERT_INTO = " INSERT INTO ";
        public static final String FROM = " FROM ";
        public static final String VALUES = " VALUES ";
        public static final String UPDATE = " UPDATE ";
        public static final String ORDER_BY = " ORDER BY ";
        public static final String PARAMETER = "?";
        public static final String BETWEEN = " BETWEEN ";

    }
}
