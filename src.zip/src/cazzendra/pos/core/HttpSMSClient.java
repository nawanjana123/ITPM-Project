/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cazzendra.pos.core;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.hc.client5.http.classic.methods.HttpGet;
import org.apache.hc.client5.http.classic.methods.HttpPost;
import org.apache.hc.client5.http.entity.UrlEncodedFormEntity;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.CloseableHttpResponse;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.core5.http.HttpEntity;
import org.apache.hc.core5.http.NameValuePair;
import org.apache.hc.core5.http.io.entity.EntityUtils;
import org.apache.hc.core5.http.message.BasicNameValuePair;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 *
 * @author Dinuka Ekanayake
 */
public class HttpSMSClient {

    public static boolean sendSms(int tempType, String to, String prntName,
            String gender, String StuName, String Subject, String regID,
            String smsGroup, String cFName, String cLName, String cEmail) throws ParseException {

        String pfn = "config/sms/template" + tempType + ".txt";
        Date currentTime = new Date();
        String formatTimeStr = "dd MMM hh:mma";
        DateFormat formatYR = new SimpleDateFormat(formatTimeStr);
        String time = formatYR.format(currentTime);
        String a[] = smsConfig();

        String txtmsg = "";
        String user_id = a[1];
        String api_key = a[2];
        String sender_id = a[3];
        String url = a[0];
        String msgto = "94" + String.valueOf(Integer.parseInt(to));
        String ge = "Female".equals(gender) ? "Daughter" : "Son";
        String[] stName = StuName.split(" ");
        String[] prName = prntName.split(" ");
        String msgBody = "";
        String cfname = cFName;
        String clname = cLName;
        String cemail = cEmail;
        String grp = "";
//        String regid = regID;

        JSONParser parser = new JSONParser();
        try {
            Object obj = parser.parse(new FileReader(pfn));
            JSONArray array = (JSONArray) obj;
            for (int i = 0; i < array.size(); i++) {
                JSONObject jsonObject = (JSONObject) array.get(i);
                txtmsg = (String) jsonObject.get("msg");
                grp = (String) jsonObject.get("group");

                switch (tempType) {

                    case 1:
                        //                Attend Success msg
                        String[] ms = txtmsg.split("#");
                        msgBody = ms[0] + prName[0] + ms[1] + ge + " " + stName[0] + ms[2].concat(Subject) + ms[3].concat(time) + ms[4];
                        System.out.println(msgBody);
                        cfname = prName[0];
                        clname = prName[1];

                        break;

                    case 2:
                        //                Attend Success Without payment
//                        "Dear #,# have'nt been paid to # class. But,consider & accept the class at #. Plz settle the payment. Thanks."
                        String[] ms1 = txtmsg.split("#");
                        msgBody = ms1[0] + prName[0] + ms1[1] + stName[0] + ms1[2].concat(Subject) + ms1[3].concat(time) + ms1[4];
                        System.out.println(msgBody);
                        cfname = prName[0];
                        clname = prName[1];
                        break;

                    case 3:
                        //                Student Registration Success 
//                        "Dear #, Your #, was registered successfuly. # - Registration Number. Thanks."
                        String[] ms2 = txtmsg.split("#");
                        msgBody = ms2[0] + prName[0] + ms2[1] + ge + " " + stName[0] + ms2[2].concat(regID) + ms2[3];
                        System.out.println(msgBody);
                        cfname = prName[0];
                        clname = prName[1];
                        break;
                        
                    case 4:
                        //                Student Registration Success 
//                        "Dear #, You have been registered successfuly. # - Registration Number. Thanks."
                        String[] ms3 = txtmsg.split("#");
                        msgBody = ms3[0] + stName[0] + ms3[1]+ regID + ms3[2];
                        System.out.println(msgBody);
                        cfname = stName[0];
                        clname = stName[1];
                        break;
                        
                    case 5:
                        
                        //                Student Registration Success 
//                        "Dear #, You have been registered successfuly. # - Registration Number. Thanks."
                        String[] ms4 = txtmsg.split("#");
                        msgBody = ms4[0] + stName[0] + ms4[1]+ regID + ms4[2];
                        System.out.println(msgBody);
                        cfname = stName[0];
                        clname = stName[1];
                        break; 
                    default:
                        break;
                }

            }
            System.out.println(url + " " + user_id + " " + api_key + " " + sender_id + " "
                    + msgto + " " + msgBody + " " + cfname + " " + clname + " " + cemail + " " + grp);

            if (sendsmsClient(url, user_id, api_key, sender_id,
                    msgto, msgBody, cfname, clname, cemail, grp)) {
                return true;
            }
        } catch (FileNotFoundException e) {
        } catch (IOException e) {
        }

        return false;
    }

    private static boolean sendsmsClient(String url, String user_id, String api_key, String sender_id,
            String msgto, String msgBody, String cFName, String cLName, String cEmail, String group) throws IOException, ParseException {
        try (CloseableHttpClient httpclient = HttpClients.createDefault()) {

            HttpPost httpPost = new HttpPost(url);

            List<NameValuePair> nvps = new ArrayList<>();

            nvps.add(new BasicNameValuePair("user_id", user_id));
            nvps.add(new BasicNameValuePair("api_key", api_key));
            nvps.add(new BasicNameValuePair("sender_id", sender_id));
            nvps.add(new BasicNameValuePair("to", msgto));
            nvps.add(new BasicNameValuePair("message", msgBody));
            nvps.add(new BasicNameValuePair("contact_fname", cFName));
            nvps.add(new BasicNameValuePair("contact_lname", cLName));
//            nvps.add(new BasicNameValuePair("contact_email", cEmail));
            nvps.add(new BasicNameValuePair("contact_group", group));

            httpPost.setEntity(new UrlEncodedFormEntity(nvps));
            try (CloseableHttpResponse response2 = httpclient.execute(httpPost)) {

                System.out.println(response2.getCode() + " " + response2.getReasonPhrase());
                HttpEntity entity2 = response2.getEntity();
                EntityUtils.consume(entity2);
                logManager.saveLog(logManager.Logger("to " + msgto + " , " + msgBody + " , " + response2.getCode() +
                        " " + response2.getReasonPhrase())+" "+checksmsBalClient());
                return response2.getCode() == 200;
            }
        }

    }

    public static String checksmsBalClient() throws IOException, ParseException {
        String a[] = smsConfig();
        String json = null;
        try (CloseableHttpClient httpclient = HttpClients.createDefault()) {
            String url = "https://app.notify.lk/api/v1/status?";

            String bindUrl = url + "user_id=" + a[1] + "&api_key=" + a[2];
            HttpGet httpGet = new HttpGet(bindUrl);

            try (CloseableHttpResponse response1 = httpclient.execute(httpGet)) {
//                System.out.println(response1.getCode() + " " + response1.getReasonPhrase());
                HttpEntity entity1 = response1.getEntity();
                if (response1.getCode() == 200) {
                    try {
                        json = EntityUtils.toString(response1.getEntity());
                        System.out.println(json);
                        EntityUtils.consume(entity1);

                        
                    } catch (org.apache.hc.core5.http.ParseException ex) {
                        Logger.getLogger(HttpSMSClient.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    return json;

                } else {
                    return null;
                }

            }
        }
    }

    private static String[] smsConfig() throws ParseException {

        String pfn = "config/sms/config.txt";
        String user_id = "";
        String api_key = "";
        String sender_id = "";
        String url = "";

        JSONParser parser = new JSONParser();
        try {
            Object obj = parser.parse(new FileReader(pfn));
            JSONArray array = (JSONArray) obj;
            for (int i = 0; i < array.size(); i++) {
                JSONObject jsonObject = (JSONObject) array.get(i);
                user_id = (String) jsonObject.get("user_id");
                api_key = (String) jsonObject.get("api_key");
                sender_id = (String) jsonObject.get("sender_id");
                url = (String) jsonObject.get("url");

            }
            String a[] = {url, user_id, api_key, sender_id};
            return a;
        } catch (FileNotFoundException e) {
        } catch (IOException e) {
        }
        return null;
    }
}
