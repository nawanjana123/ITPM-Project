/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cazzendra.pos.core;

import com.sun.pisces.Surface;
import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JDialog;
import javax.swing.JOptionPane;

/**
 *
 * @author Dinuka Ekanayake
 */
public class IdGenarator {

    int DPI = 0;
    int IMGPx = 0;
    double PGT = 0.0;
    int FontSize = 0;
    String FontFamily = "";

    public static BufferedImage loadQRImage(String path) {
        try {
            BufferedImage image = ImageIO.read(new File(path));
            int org_att_img_width = image.getWidth();
            int org_att_img_height = image.getHeight();
//            double nH=(image.getHeight())*(Integer.parseInt(txtAtt_img_scl.getValue().toString())/100.0);
//            double nW=(image.getWidth())*(Integer.parseInt(txtAtt_img_scl.getValue().toString())/100.0);
//            new_height=(int) nH;
//            new_width=(int) nW;

//System.out.println(image.createGraphics());
            return image;
        } catch (Exception ex) {
            Logger.getLogger(Surface.class.getName()).log(Level.WARNING, null, ex);
            return null;
        }
    }

    public static void CreateIMG(String Filename) throws IOException{
        int pgHd=0;      
        int pgWd=0;
        
        BufferedImage buffImg=new BufferedImage(pgHd, pgWd, BufferedImage.TYPE_INT_RGB);
        Graphics2D grp=buffImg.createGraphics();
        Graphics2D grp2=buffImg.createGraphics();
        File file=new File(".tmp/.tmp32/"+Filename);
        ImageIO.write(buffImg, "png", file);
    }
    
    public void LoadConfigFile(String fileName) throws IOException {
        String ConfigFile = fileName + ".xml";

        String line = "";
        try {
            // FileReader reads text files in the default encoding.
            FileReader fileReader = new FileReader(ConfigFile);
            // Always wrap FileReader in BufferedReader.
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            while ((line = bufferedReader.readLine()) != null) {
                String[] txt = line.split(",");
                DPI = Integer.parseInt(txt[0]);
                PGT = Double.parseDouble(txt[1]);
                FontSize = Integer.parseInt(txt[2]);
                FontFamily = txt[3];
//                System.out.println(DPI +" \n"+FontFamily);
            }

            // Always close files.
            bufferedReader.close();
        } catch (FileNotFoundException ex) {
            JOptionPane optionPane = new JOptionPane("Unable to open file '" + ConfigFile + "'", JOptionPane.ERROR_MESSAGE);
            JDialog dialog = optionPane.createDialog("Failure");
            dialog.setAlwaysOnTop(true);
            dialog.setVisible(true);
        }
    }
}
