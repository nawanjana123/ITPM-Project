/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cazzendra.pos.core;

/**
 *
 * @author 4m4l
 */
public enum MethodStatus {
    SUCCESS,
    FAILED,
    DUPLICATE_PRIMARY_KEY,
    HAS_EMPTY_FIELDS
}
