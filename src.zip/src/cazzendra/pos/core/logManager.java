/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cazzendra.pos.core;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author Dinuka Ekanayake
 */
public class logManager {

    public static void saveLog(String txtLog){
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");
    Date now = new Date();
    String strDate = sdf.format(now);
    try (Writer writer = new BufferedWriter(new OutputStreamWriter(
            new FileOutputStream("~logs/sms/logMaster_"+strDate+".log"), "utf-8"))) {
            writer.write(txtLog);
    } catch (IOException ex) {
//            Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
    }
}
    public static String nowTime(){
                Date currentTime = new Date();
                String formatTimeStr = "YYYY dd MMM  hh : mm ss a";
                DateFormat formatYR = new SimpleDateFormat(formatTimeStr);
                return formatYR.format(currentTime);
    }
    
    public static String Logger(String line){
        String txt = nowTime()+",\t"+line+"\n";
        return txt;
    } 
}
