/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cloudrevel.lnguage.src.keys;

/**
 *
 * @author personal
 */
public class LangSinhala {

    public static String LABEL_SINHALA_ITEM_SEARCH_SEARCH_BY_ITEM_NAME_ITEM_BARCODE = "item-search-by-name-item-code-barcode-sinhala";
    public static String LABEL_ITEM_SEARCH_SEARCH_BY_ITEM_NAME_ITEM_BARCODE = "item-search-by-name-item-code-barcode";

    public static String TBL_HDR_ITEM_CODE_SINHALA = "tbl-hdr-item-code-sinhala";
    public static String TBL_HDR_ITEM_CODE = "tbl-hdr-item-code";

    public static String TBL_HDR_ITEM_BARCODE_SINHALA = "item-barcode-sinhala";
    public static String TBL_HDR_ITEM_BARCODE = "item-barcode";

    public static String TBL_HDR_ITEM_NAME_SINHALA = "tbl-hdr-item-name-sinhala";
    public static String TBL_HDR_ITEM_NAME = "tbl-hdr-item-name";

    public static String LABEL_SEARCH_CUSTOMER_BY_NAME_ADDRESS_CONTACT_SINHALA = "search-customer-by-name-address-contact-sinhala";
    public static String LABEL_SEARCH_CUSTOMER_BY_NAME_ADDRESS_CONTACT = "search-customer-by-name-address-contact";

    public static String TBL_HDR_NAME_SINHALA = "tbl-hdr-name-sinhala";
    public static String TBL_HDR_NAME = "tbl-hdr-name";

    public static String TBL_HDR_ADDRESS_SINHALA = "tbl-hdr-address-sinhala";
    public static String TBL_HDR_ADDRESS = "tbl-hdr-address";

    public static String TBL_HDR_CONTACT1_SINHALA = "tbl-hdr-contact1-sinhala";
    public static String TBL_HDR_CONTACT1 = "tbl-hdr-contact1";

    public static String TBL_HDR_CONTACT2_SINHALA = "tbl-hdr-contact2-sinhala";
    public static String TBL_HDR_CONTACT2 = "tbl-hdr-contact2";

    public static String LBL_PRINT_LANGUAGE_SINHALA = "print-language-sinhala";
    public static String LBL_PRINT_LANGUAGE = "print-language";

    public static String LBL_ITEM_BARCODE_SINHALA = "item-barcode-blue-sinhala";
    public static String LBL_ITEM_BARCODE = "item-barcode-blue";

    public static String LBL_ITEM_NAME_SINHALA = "item-name-sinhala";
    public static String LBL_ITEM_NAME = "item-name";

    public static String LBL_ITEM_CODE_SINHALA = "item-code-sinhala";
    public static String LBL_ITEM_CODE = "item-code";

    public static String LBL_ITEM_MAIN_CATEGORY_SINHALA = "main-category-sinhala";
    public static String LBL_ITEM_MAIN_CATEGORY = "main-category";

    public static String LBL_ITEM_SUB_CATEGORY_SINHALA = "sub-category-sinhala";
    public static String LBL_ITEM_SUB_CATEGORY = "sub-category";

    public static String LBL_ITEM_RE_ORDER_LEVEL_SINHALA = "re-order-level-sinhala";
    public static String LBL_ITEM_RE_ORDER_LEVEL = "re-order-level";

    public static String LBL_ITEM_RETAIL_PRICE_SINHALA = "retail-price-blue-sinhala";
    public static String LBL_ITEM_RETAIL_PRICE = "retail-price-blue";

    public static String TBL_HDR_ITEM_RE_ORDER_LEVEL_SINHALA = "tbl-hdr-reoreder-level-sinhala";
    public static String TBL_HDR_ITEM_RE_ORDER_LEVEL = "tbl-hdr-reoreder-level";

    public static String TBL_HDR_ITEM_RETAIL_PRICE_SINHALA = "tbl-hdr-retail-price-sinhala";
    public static String TBL_HDR_ITEM_RETAIL_PRICE = "tbl-hdr-retail-price";

}
