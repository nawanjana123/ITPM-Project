/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ttms.controller;

import com.ttms.daoimpl.sesionDaoImpl;
import com.ttms.model.sesion;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author personal
 */
public class sesionController {

    public static boolean addSubject(String courseLevel, String detail,
            String moduleCode, String subjectName, String semester, int courseId) throws SQLException {
        sesion subject = new sesion();
        subject.setCourseLevel(courseLevel);
        subject.setDetail(detail);
        subject.setModuleCode(moduleCode);
        subject.setName(subjectName);
        subject.setSemester(semester);
        subject.setStatus(subject.ACTIVE_SUBJECT);
        subject.setCourseId(courseId);
        return new sesionDaoImpl().addSubject(subject);
    }

    public static ResultSet getAllSubjects() throws SQLException {
        return new sesionDaoImpl().getAllSubject();
    }

    public static ResultSet getSubjectByOneAttribute(String attribute,
            String condition, String value) throws SQLException {
        return new sesionDaoImpl().getSubjectByOneAttribute(attribute, condition, value);
    }

    public static boolean updateSubject(sesion subject) throws SQLException {
        return new sesionDaoImpl().updateSubject(subject);
    }

    public static sesion getSubjectBySubjectId(int subjectId) throws SQLException {
        ResultSet rset = getSubjectByOneAttribute("subject_id", commonConstants.Sql.EQUAL, Integer.toString(subjectId));
        sesion subject = null;
        while (rset.next()) {
            subject = new sesion();
            subject.setCourseId(rset.getInt("subject_course_id"));
            subject.setCourseLevel(rset.getString("subject_course_level"));
            subject.setSemester(rset.getString("subject_semester"));
            subject.setName(rset.getString("subject_name"));
            subject.setId(rset.getInt("subject_id"));
            subject.setModuleCode(rset.getString("subject_module_code"));
            subject.setDetail(rset.getString("subject_detail"));
            subject.setStatus(rset.getInt("subject_status"));
        }
        return subject;
    }

    public static ResultSet getActiveAndCourseJoinedSubjectDetails() throws SQLException {
        return new sesionDaoImpl().getActiveAndCourseJoinedSubjectDetails();
    }
    
    public static ResultSet getSubjectByMoreAttributes(ArrayList<String[]> attributeConditionValueList, String operator) throws SQLException {
        return new sesionDaoImpl().getSubjectByMoreAttributes(attributeConditionValueList, operator);
    }
    
}
