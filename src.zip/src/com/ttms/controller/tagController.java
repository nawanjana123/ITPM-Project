/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ttms.controller;

import com.ttms.daoimpl.tagDaoImpl;
import com.ttms.model.tag;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author personal
 */
public class tagController {

    public static ResultSet getAllBatches() throws SQLException {
        return new tagDaoImpl().getAllBatches();
    }

    public static ResultSet getBatchByOneAttribute(String attribute, String condition, String value) throws SQLException {
        return new tagDaoImpl().getBatchByOneAttribute(attribute, condition, value);
    }

    public static boolean addBatch(String year, String level, String detail) throws SQLException {
        tag batch = new tag();
        batch.setYear(year);
        batch.setLevel(level);
        batch.setDetail(detail);
        batch.setStatus(batch.ACTIVE_BATCH);
        return new tagDaoImpl().addBatch(batch);
    }

    public static boolean updateAsDeleted(int batchId) throws SQLException {
        return new tagDaoImpl().updateBatchAsDeleted(batchId);
    }

    public static boolean updateBatch(tag batch) throws SQLException {
        return new tagDaoImpl().updateBatch(batch);
    }

    public static tag getBatchModelByBatchId(int batchId) throws SQLException {
        ResultSet rset = tagController.getBatchByOneAttribute("batch_id", commonConstants.Sql.EQUAL, Integer.toString(batchId));
        tag batch = null;
        while (rset.next()) {
            batch = new tag();
            batch.setDetail(rset.getString("batch_detail"));
            batch.setId(rset.getInt("batch_id"));
            batch.setLevel(rset.getString("batch_level"));
            batch.setYear(rset.getString("batch_year"));
            batch.setStatus(rset.getInt("batch_status"));
        }
        return batch;
    }

}
