/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ttms.databaseConnection;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 * @Dinuka_Ekanayake 
 */
public class DatabaseConnection {

    private DatabaseConnection() {
    }

    public static Connection getDatabaseConnection() throws SQLException {
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException ex) {
            Logger.getLogger(DatabaseConnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        String a[]=dbConfig();
        Connection con = DriverManager.getConnection("jdbc:mysql://".concat(a[0]), a[1], a[2]);
        return con;
    }
 private static String[] dbConfig() {

        String pfn = "config\\db_config.txt";
        String user = "";
        String pass = "";
        String url = "";

        JSONParser parser = new JSONParser();
        try {
            Object obj = parser.parse(new FileReader(pfn));
            JSONArray array = (JSONArray) obj;
            for (int i = 0; i < array.size(); i++) {
                JSONObject jsonObject = (JSONObject) array.get(i);
                user = (String) jsonObject.get("user");
                pass = (String) jsonObject.get("pass");
                url = (String) jsonObject.get("url");

            }
            String a[] = {url, user, pass};
            return a;
        } catch (FileNotFoundException e) {
        } catch (IOException | ParseException e) {
        }
        return null;
    }
}

