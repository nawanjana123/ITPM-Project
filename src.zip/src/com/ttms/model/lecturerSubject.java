/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ttms.model;

/**
 *
 * @author Amal
 */
public class lecturerSubject {

    private int id;
    private int lecturerId;
    private int subjectId;
    private String detail1;
    private String detail2;
    private String detail3;
    private int status1;
    private int status2;
    private int status3;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the lecturerId
     */
    public int getLecturerId() {
        return lecturerId;
    }

    /**
     * @param lecturerId the lecturerId to set
     */
    public void setLecturerId(int lecturerId) {
        this.lecturerId = lecturerId;
    }

    /**
     * @return the subjectId
     */
    public int getSubjectId() {
        return subjectId;
    }

    /**
     * @param subjectId the subjectId to set
     */
    public void setSubjectId(int subjectId) {
        this.subjectId = subjectId;
    }

    /**
     * @return the detail1
     */
    public String getDetail1() {
        return detail1;
    }

    /**
     * @param detail1 the detail1 to set
     */
    public void setDetail1(String detail1) {
        this.detail1 = detail1;
    }

    /**
     * @return the detail2
     */
    public String getDetail2() {
        return detail2;
    }

    /**
     * @param detail2 the detail2 to set
     */
    public void setDetail2(String detail2) {
        this.detail2 = detail2;
    }

    /**
     * @return the detail3
     */
    public String getDetail3() {
        return detail3;
    }

    /**
     * @param detail3 the detail3 to set
     */
    public void setDetail3(String detail3) {
        this.detail3 = detail3;
    }

    /**
     * @return the status1
     */
    public int getStatus1() {
        return status1;
    }

    /**
     * @param status1 the status1 to set
     */
    public void setStatus1(int status1) {
        this.status1 = status1;
    }

    /**
     * @return the status2
     */
    public int getStatus2() {
        return status2;
    }

    /**
     * @param status2 the status2 to set
     */
    public void setStatus2(int status2) {
        this.status2 = status2;
    }

    /**
     * @return the status3
     */
    public int getStatus3() {
        return status3;
    }

    /**
     * @param status3 the status3 to set
     */
    public void setStatus3(int status3) {
        this.status3 = status3;
    }

}
